A Pen created at CodePen.io. You can find this one at https://codepen.io/Creaticode/pen/xIfmw.

 Slider Responsive sumamente funcional y estetico.