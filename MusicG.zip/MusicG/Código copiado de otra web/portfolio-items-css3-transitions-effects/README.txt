A Pen created at CodePen.io. You can find this one at https://codepen.io/fox_hover/pen/wYrvod.

 Portfolio Items CSS3 transitions effects (pure CSS3)