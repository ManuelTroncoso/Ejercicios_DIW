function Mostrar(x) {
    if (x.className == "Show") {
        x.className = "hidden";
        //Hacer que aparezca despacio.
    }
    else {
        x.className = "Show";
    }
}

$(document).ready(function () {
    $(window).bind('scroll', function () {
        var navHeight = 168.5;
        if ($(window).scrollTop() > navHeight) {
            $('nav').addClass('fixed');
            $('body').addClass('arreglopadding');
        }
        else {
            $('nav').removeClass('fixed');
            $('body').removeClass('arreglopadding')
        }
    });
});